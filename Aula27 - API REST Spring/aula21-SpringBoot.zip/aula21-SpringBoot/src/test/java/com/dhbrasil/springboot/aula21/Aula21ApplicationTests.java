package com.dhbrasil.springboot.aula21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
