package com.dhbrasil.springboot.aula21.model;

public class Endereco {



}
